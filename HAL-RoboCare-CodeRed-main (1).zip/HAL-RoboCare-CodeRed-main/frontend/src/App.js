// import Chatbot from "./page/chatbot"

// function App() {
//   return (
//     <div className="app">
//       <Chatbot />
//     </div>
//   )
// }

// export default App


import Chat from "./page/chat"

function App() {
  return (
    <div className="app">
      <Chat />
    </div>
  )
}

export default App
